// Initialisation des variables
_Relais = new Array();
_Pulse = new Array();
_Input = "Entrée";
const _urlvm201cde = "/cgi/leds.cgi?led=";
const _urlvm201status = "/cgi/status.cgi";
const _urlvm201timer = "/cgi/timers.cgi?timer=";
const _urlvm201input = "/cgi/input.cgi?input=0";

exports.init = function (SARAH) {
  var config = SARAH.ConfigManager.getConfig().modules.vm201;
  getVariables(config, SARAH);
  updateXML();
}

exports.action = function(data, callback, config, SARAH){
	// Recuperation de la config
	config = config.modules.vm201;
  getVariables(config, SARAH);

	if (config.IP_VM201 == ""){
		//console.log("La variable IP_VM201 n'est pas configurée");
		return callback({'tts' : "La variable, IP, VM201, n'est pas configurée."});
	}

	if (config.Port_VM201 == ""){
		//console.log("La variable Port_VM201 n'est pas configurée");
		return callback({'tts' : "La variable, Port, VM201, n'est pas configurée."});
	}

  if (data.commande) {
    var tmp = data.tmp;
    var key = data.key;
    var cde = data.commande;
    //console.log(" Exports ==> Tmp : " + tmp + " Key : " + key + " cde : " + cde);

    doAction(config, cde, tmp, key, callback, SARAH);
  } else {
    callback();
  }
  return;
}

function doAction(config, cde, tmp, key, callback, SARAH) {
	// Init. variables
	var _IP_VM201 = config.IP_VM201;
	var _Port_VM201 = config.Port_VM201;
	var _Utilisateur = config.Utilisateur;
	var _Mot_de_passe = config.Mot_de_passe;
  var auth="";
  var url = "";

  switch (cde) {
  case 'on' :
    if (_IP_VM201) {
      if (tmp == "0") {
        doStatus('relay', key, config, callback, SARAH, function(arelay) {
          if (arelay == "0") {
            if (_Pulse[key] == "" || _Pulse[key] == "0") {
              url = "http://" + _IP_VM201 + _urlvm201cde + key;
              sendURL(url, config, callback, SARAH, function(body){
                if (body.substring(0,7) == 'Success') {
                  callback({"tts":_Relais[key] + ", Action effectuée."});
                } else {
                  callback({"tts":"Une erreur est survenue, l'action ne s'est pas correctement effectuée."});
                }
              });
            } else {
              SARAH.speak("ok!");
              url = "http://" + _IP_VM201 + _urlvm201cde + key;
              sendURL(url, config, callback, SARAH, function(body){
                if (body.substring(0,7) == 'Success') {
                  setTimeout(function(){sendURL(url, config, callback, SARAH, function(body2){
                    if (body2.substring(0,7) == 'Success') {
                      callback({"tts":_Relais[key] + ", Action effectuée."});
                    } else {
                      callback({"tts":"Une erreur est survenue, l'action ne s'est pas correctement effectuée."});
                    }
                  })}, (_Pulse[key] * 1000));
                } else {
                  callback({"tts":"Une erreur est survenue, l'action ne s'est pas correctement effectuée."});
                }
              });
            }
          } else {
            callback({"tts":"Cette commande est déjà active."});
          }
        });
        return;
      } else {
        doStatus('timer', key, config, callback, SARAH, function(arelay) {
          if (arelay == "0") {
            url = "http://" + _IP_VM201 + _urlvm201timer + key;
            sendURL(url, config, callback, SARAH, function(body){
              if (body.substring(0,7) == 'Success') {
                callback({"tts":"La temporisation " + _Relais[key] + ", a été activée."});
              } else {
                callback({"tts":"Une erreur est survenue, l'action ne s'est pas correctement effectuée."});
              }
            });
          } else {
            callback({"tts":"Cette temporisation est déjà active."});
          }
        });
        return;
      }
    } else {
      callback({"tts":"L'adresse IP n'est pas configurée."});
      return;
    }
    break;

  case 'off':
    if (_IP_VM201) {
      if (tmp == "0") {
        doStatus('relay', key, config, callback, SARAH, function(arelay) {
          if (arelay == "1") {
            if (_Pulse[key] == "" || _Pulse[key] == "0") {
              url = "http://" + _IP_VM201 + _urlvm201cde + key;
              sendURL(url, config, callback, SARAH, function(body){
                if (body.substring(0,7) == 'Success') {
                  callback({"tts":_Relais[key] + ", Action effectuée."});
                } else {
                  callback({"tts":"Une erreur est survenue, l'action ne s'est pas correctement effectuée."});
                }
              });
            } else {
              callback({"tts":"Merci d'attendre la fin de la commande précédente."});
            }
          } else {
            if (_Pulse[key] != "" && _Pulse[key] != "0") {
              SARAH.speak("ok!");
              url = "http://" + _IP_VM201 + _urlvm201cde + key;
              sendURL(url, config, callback, SARAH, function(body){
                if (body.substring(0,7) == 'Success') {
                  setTimeout(function(){sendURL(url, config, callback, SARAH, function(body2){
                    if (body2.substring(0,7) == 'Success') {
                      callback({"tts":_Relais[key] + ", Action effectuée."});
                    } else {
                      callback({"tts":"Une erreur est survenue, l'action ne s'est pas correctement effectuée."});
                    }
                  })}, (_Pulse[key] * 1000));
                } else {
                  callback({"tts":"Une erreur est survenue, l'action ne s'est pas correctement effectuée."});
                }
              });
            } else {
              callback({"tts":"Cette commande est déjà désactivée."});
            }            
          }
        });
        return;
      } else {
        doStatus('timer', key, config, callback, SARAH, function(arelay) {
          if (arelay == "1") {
            url = "http://" + _IP_VM201 + _urlvm201timer + key;
            sendURL(url, config, callback, SARAH, function(body){
              if (body.substring(0,7) == 'Success') {
                callback({"tts":"La temporisation " + _Relais[key] + ", a été désactivée."});
              } else {
                callback({"tts":"Une erreur est survenue, l'action ne s'est pas correctement effectuée."});
              }
            });
          } else {
            callback({"tts":"Cette temporisation est déjà active."});
          }
        });
        return;
      }
    } else {
      callback({"tts":"L'adresse IP n'est pas configurée."});
      return;
    }
    break;

  case 'etat':
    var eMale = new Array();
    var eFemale = new Array();
    eMale[0] = "inactif";
    eMale[1] = "actif";
    eFemale[0] = "inactive";
    eFemale[1] = "active";
    var statut = "";
    var valeur = "";
    //console.log("Etat ==> key : " + key + " tmp : " + tmp);

    url = "http://" + _IP_VM201 + _urlvm201status;
    sendURL(url, config, callback, SARAH, function(body){
      var xml2js = require('xml2js');
      var parser = new xml2js.Parser({trim: true});
      
      parser.parseString(body, function (err, xml) {
        switch (key) {
        case '-1':
          for (var i=0; i<8; i++) {
            valeur = xml.status.leds[0].led[i]._;
            if (valeur == '1') {
              statut += _Relais[i] + " est " + eMale[valeur] + ", \r\n";
            }
          }

          for (var i=0; i<8; i++) {
            valeur = xml.status.timers[0].timer[i]._;
            if (valeur == '1') {
              statut += "La temporisation " + _Relais[i] + " est " + eMale[valeur] + ", \r\n";
            }
          }

          valeur = xml.status.input[0]._;
          if (valeur == '1') {
            statut += _Input + " est " + eMale[valeur] + ", \r\n";
          }

          if (statut) {
            callback({"tts":statut});
          } else {
            callback({"tts":"Aucune commande active."});
          }
          break;

        default:
          if (key < 8 && tmp == "0") {
            doStatus('relay', key, config, callback, SARAH, function(arelay) {
              callback({"tts":_Relais[key] + " est " + eMale[arelay]});
            });
          } else if (key == 8 && tmp == "0") {
            doStatus('input', key, config, callback, SARAH, function(arelay) {
              callback({"tts": _Input + " est " + eMale[arelay]});
            });
          } else if (key < 8 && tmp == "1") {
            doStatus('timer', key, config, callback, SARAH, function(arelay) {
              callback({"tts":"La temporisation " + _Relais[(parseInt(key)+1)] + " est " + eFemale[arelay]});
            });
          } else {
            callback({"tts":"Je n'ai pas compris la question."});
          }
          break;
        }
      }); 
    });
    return;

    break;
  case 'doc':
    // Affichage de la documentation
    SARAH.remote({ 'run' : 'AcroRd32.exe', 'runp' : './plugins/vm201/docs/usermanual_vm201.pdf' });
    callback({'tts': "La documentation est affichée !"});
    return;
    break;

  case 'cde':
    // Affichage de la documentation
    SARAH.remote({ 'run' : 'explorer', 'runp' : __dirname + '\\docs\\commandes.html' });
    callback({'tts': "La liste des commandes est affichée !"});
    return;
    break;

  case 'info':
    // Sarah lit les infos du fonctionnement du plugin
    var fs = require('fs');
    var _contenu = fs.readFileSync("./plugins/vm201/docs/infos.txt", "UTF-8");
    //console.log(_contenu);
    callback({'tts': _contenu });
    return;
    break;

  default:
    callback({'tts': "Je n'ai pas compris la commande!"});
    return;
    break;
  }
}

var doStatus = function (obj, key, config, callback, SARAH, cb) {
	// Init. variables
	var _IP_VM201 = config.IP_VM201;
	var _Port_VM201 = config.Port_VM201;
	var _Utilisateur = config.Utilisateur;
	var _Mot_de_passe = config.Mot_de_passe;
  var url = "";
  var valeur = "0";

  if (_IP_VM201) {
    url = "http://" + _IP_VM201 + _urlvm201status;
    sendURL(url, config, callback, SARAH, function(body){
      var xml2js = require('xml2js');
      var parser = new xml2js.Parser({trim: true});
      parser.parseString(body, function (err, xml) {
        switch (obj) {
        case 'relay':
          valeur = xml.status.leds[0].led[key]._;
          break;
        case 'timer':
          valeur = xml.status.timers[0].timer[key]._;
          break;
        case 'input':
          valeur = xml.status.input[0]._;
          break;
        }
        if (valeur == "") {
          valeur = "0";
        }
        cb(valeur);
      }); 
    });
  } else {
    SARAH.speak("L'adresse IP n'est pas configurée.");
  }
}

var sendURL = function(url, config, callback, SARAH, cb){
	// Init. variables
	var _IP_VM201 = config.IP_VM201;
	var _Port_VM201 = config.Port_VM201;
	var _Utilisateur = config.Utilisateur;
	var _Mot_de_passe = config.Mot_de_passe;
  var auth="";

  if (_Utilisateur && _Mot_de_passe) {
    auth = 'Basic ' + new Buffer(_Utilisateur + ':' + _Mot_de_passe).toString('base64');
  }
  var request = require('request');
  request({url : url, headers : {"Authorization" : auth}}, function (err, response, body) {
    
    if (err || response.statusCode != 200) {
      //console.log("erreur : " + err);
      SARAH.speak("L'action a échouée " + err);
      return;
    }

    cb(body);
  });
}

function getVariables(config, SARAH) {
  _Relais[0] = (config.Relais_1 == "" ? "Relais 1" : config.Relais_1);
  _Relais[1] = (config.Relais_2 == "" ? "Relais 2" : config.Relais_2);
  _Relais[2] = (config.Relais_3 == "" ? "Relais 3" : config.Relais_3);
  _Relais[3] = (config.Relais_4 == "" ? "Relais 4" : config.Relais_4);
  _Relais[4] = (config.Relais_5 == "" ? "Relais 5" : config.Relais_5);
  _Relais[5] = (config.Relais_6 == "" ? "Relais 6" : config.Relais_6);
  _Relais[6] = (config.Relais_7 == "" ? "Relais 7" : config.Relais_7);
  _Relais[7] = (config.Relais_8 == "" ? "Relais 8" : config.Relais_8);
  _Pulse[0] = (config.Pulse_1 == "" ? "" : config.Pulse_1);
  _Pulse[1] = (config.Pulse_2 == "" ? "" : config.Pulse_2);
  _Pulse[2] = (config.Pulse_3 == "" ? "" : config.Pulse_3);
  _Pulse[3] = (config.Pulse_4 == "" ? "" : config.Pulse_4);
  _Pulse[4] = (config.Pulse_5 == "" ? "" : config.Pulse_5);
  _Pulse[5] = (config.Pulse_6 == "" ? "" : config.Pulse_6);
  _Pulse[6] = (config.Pulse_7 == "" ? "" : config.Pulse_7);
  _Pulse[7] = (config.Pulse_8 == "" ? "" : config.Pulse_8);
  _Input = (config.Input == "" ? "Entrée" : config.Input);
}

var AddItem=function(place, tmp, index) {
  if (typeof place==='undefined' || place=="")
    return "";
  return "			<item>" + place + "<tag>out.action.tmp=\"" + tmp + "\";out.action.key=\"" + index + "\";</tag></item>\r\n";
}

function updateXML() {
  var xmlfile=__dirname + "/vm201.xml";
  var config_xml="";
  var fs   = require('fs');
  var xml  = fs.readFileSync(xmlfile,'utf8');
  var regexp = new RegExp('§[^§]+§','gm');
  i=0;
  config_xml="\r\n		<one-of>\r\n";
  config_xml+=AddItem(_Relais[0], '0', i++);
  config_xml+=AddItem(_Relais[1], '0', i++);
  config_xml+=AddItem(_Relais[2], '0', i++);
  config_xml+=AddItem(_Relais[3], '0', i++);
  config_xml+=AddItem(_Relais[4], '0', i++);
  config_xml+=AddItem(_Relais[5], '0', i++);
  config_xml+=AddItem(_Relais[6], '0', i++);
  config_xml+=AddItem(_Relais[7], '0', i++);
  i=0;
  config_xml+=AddItem("Tampo " + _Relais[0], '1', i++);
  config_xml+=AddItem("Tampo " + _Relais[1], '1', i++);
  config_xml+=AddItem("Tampo " + _Relais[2], '1', i++);
  config_xml+=AddItem("Tampo " + _Relais[3], '1', i++);
  config_xml+=AddItem("Tampo " + _Relais[4], '1', i++);
  config_xml+=AddItem("Tampo " + _Relais[5], '1', i++);
  config_xml+=AddItem("Tampo " + _Relais[6], '1', i++);
  config_xml+=AddItem("Tampo " + _Relais[7], '1', i++);
  i=0;
  config_xml+=AddItem("Temporisation " + _Relais[0], '1', i++);
  config_xml+=AddItem("Temporisation " + _Relais[1], '1', i++);
  config_xml+=AddItem("Temporisation " + _Relais[2], '1', i++);
  config_xml+=AddItem("Temporisation " + _Relais[3], '1', i++);
  config_xml+=AddItem("Temporisation " + _Relais[4], '1', i++);
  config_xml+=AddItem("Temporisation " + _Relais[5], '1', i++);
  config_xml+=AddItem("Temporisation " + _Relais[6], '1', i++);
  config_xml+=AddItem("Temporisation " + _Relais[7], '1', i++);
  i=0;
  config_xml+=AddItem("Temporisateur " + _Relais[0], '1', i++);
  config_xml+=AddItem("Temporisateur " + _Relais[1], '1', i++);
  config_xml+=AddItem("Temporisateur " + _Relais[2], '1', i++);
  config_xml+=AddItem("Temporisateur " + _Relais[3], '1', i++);
  config_xml+=AddItem("Temporisateur " + _Relais[4], '1', i++);
  config_xml+=AddItem("Temporisateur " + _Relais[5], '1', i++);
  config_xml+=AddItem("Temporisateur " + _Relais[6], '1', i++);
  config_xml+=AddItem("Temporisateur " + _Relais[7], '1', i++);
  config_xml+="			<item>Entrée<tag>out.action.tmp=\"0\";out.action.key=\"8\";</tag></item>\r\n";
	config_xml+="			<item>Toutes les tampo<tag>out.action.tmp=\"1\";out.action.key=\"-1\";</tag></item>\r\n";
	config_xml+="			<item>Toutes les temporisations<tag>out.action.tmp=\"1\";out.action.key=\"-1\";</tag></item>\r\n";
	config_xml+="			<item>Toutes les temporisateurs<tag>out.action.tmp=\"1\";out.action.key=\"-1\";</tag></item>\r\n";
	config_xml+="  	  <item>Tous les relais<tag>out.action.tmp=\"0\";out.action.key=\"-1\";</tag></item>\r\n";
	config_xml+="  	  <item>Toutes les sorties<tag>out.action.tmp=\"0\";out.action.key=\"-1\";</tag></item>\r\n";
	config_xml+="  	  <item>Tous les etats<tag>out.action.tmp=\"0\";out.action.key=\"-1\";</tag></item>\r\n";
  config_xml+="		</one-of>\r\n\r\n";
  xml = xml.replace(regexp, "§ -->\r\n" + config_xml + "		<!-- §");
  fs.writeFileSync(xmlfile, xml, 'utf8');
}
